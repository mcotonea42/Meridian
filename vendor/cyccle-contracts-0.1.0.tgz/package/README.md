# Cyccle public contracts

Stable runtime contracts shared by Cyccle's public packages and Merchant API.

Import only the contract family you need:

```ts
import { HostedCancellationLinkSchema } from '@cyccle/contracts/merchant-cancellation'
import { ApiErrorResponseSchema } from '@cyccle/contracts/api-error'
```

The package intentionally has no root export. New public contract families are
added as explicit subpaths so internal schemas do not become public by accident.

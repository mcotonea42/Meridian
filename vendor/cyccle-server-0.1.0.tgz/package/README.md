# Cyccle server SDK

The server-only SDK for Cyccle's Merchant API. It requires Node.js 22 or newer
and must never be bundled into browser code because it carries a secret API key.

```ts
import { Cyccle } from '@cyccle/server'

const cyccle = new Cyccle({ apiKey: process.env.CYCCLE_API_KEY! })

const cancellation = await cyccle.cancellations.create({
  customerId: 'cus_123',
  subscriptionId: 'sub_123',
  idempotencyKey: 'cancel-attempt:customer-123',
})

const result = await cyccle.cancellations.retrieve(cancellation.id)
```

`create` never generates an idempotency key and the SDK never retries requests.
Both methods accept `{ signal }` as a second argument. The default API origin is
`https://api.cyccle.co`; `baseUrl` can override it for staging or loopback tests.
